import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense

# Load the historical sensor data from a text file (replace 'path_to_file' with your file path)
data = pd.read_csv('path_to_file', delimiter='\t')

# Preprocess the data
data_values = data.values.astype(float)
scaler = MinMaxScaler(feature_range=(0, 1))
scaled_data = scaler.fit_transform(data_values)

# Define a function to create sequences for LSTM training
def create_sequences(data, seq_length):
    X, y = [], []
    for i in range(len(data) - seq_length):
        X.append(data[i:i+seq_length, :])
        y.append(data[i+seq_length, :])
    return np.array(X), np.array(y)

# Set sequence length and split into train and test sets
sequence_length = 10  # Number of time steps to look back
X, y = create_sequences(scaled_data, sequence_length)

# Split into train and test sets
train_size = int(len(X) * 0.8)
X_train, X_test = X[:train_size], X[train_size:]
y_train, y_test = y[:train_size], y[train_size:]

# Build LSTM model
model = Sequential()
model.add(LSTM(100, input_shape=(X_train.shape[1], X_train.shape[2])))
model.add(Dense(3))  # Assuming X, Y, Z values are predicted
model.compile(loss='mean_squared_error', optimizer='adam')

# Train the model
history = model.fit(X_train, y_train, epochs=50, batch_size=32, verbose=1)

# Make predictions
predicted_values = model.predict(X_test)

# Inverse transform predictions and actual values
predicted_values = scaler.inverse_transform(predicted_values)
y_test = scaler.inverse_transform(y_test)

# Plot predicted vs. actual values
plt.figure(figsize=(12, 6))
plt.plot(predicted_values[:, 0], label='Predicted X')
plt.plot(predicted_values[:, 1], label='Predicted Y')
plt.plot(predicted_values[:, 2], label='Predicted Z')
plt.plot(y_test[:, 0], label='Actual X', linestyle='--')
plt.plot(y_test[:, 1], label='Actual Y', linestyle='--')
plt.plot(y_test[:, 2], label='Actual Z', linestyle='--')
plt.title('Sensor Data Prediction - Next 10 Seconds')
plt.xlabel('Time Steps')
plt.ylabel('Sensor Values')
plt.legend()
plt.show()
